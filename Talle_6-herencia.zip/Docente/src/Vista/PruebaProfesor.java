
package Vista;
import Modelo.*;
import java.util.Date;


public class PruebaProfesor {
    
    public static void main(String[] args) {
        
        
        
        Profesor Test1 = new Profesor("Prof 22-387-11" +"] (test1)", "Juan Hernández García");
        System.out.println("[Profesor de nombre:  "+Test1.retornarDatos());
        
        Date fecha = new Date();
        
        ProfesorInterino Test2 = new ProfesorInterino(1);
        System.out.println(Test2.retornarDatos()+ fecha+']'+ " (test2)");
        
        
        
        
        
        
    }
    
}
