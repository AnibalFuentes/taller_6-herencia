package Modelo;



public class ProfesorInterino extends Profesor {

    private int numProInt;


    public ProfesorInterino() {
    }


    public ProfesorInterino(int numProInt){
        
        this.numProInt = numProInt;
        
    }

    public int getNumProInt() {
        return numProInt;
    }

    public void setNumProInt(int numProInt) {
        this.numProInt = numProInt;
    }
    
    
    @Override
    public String retornarDatos() {
        return "[Profesor Interino "+ numProInt + " se incorporó en la fecha: ";
    }

    
}
