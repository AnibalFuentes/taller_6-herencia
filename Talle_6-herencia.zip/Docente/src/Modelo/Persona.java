package Modelo;

public class Persona {

    private String nomPersona;

    public Persona() {
    }

    public Persona(String nomPersona) {
        this.nomPersona = nomPersona;
    }

    public String getNomPersona() {
        return nomPersona;
    }

    public void setNomPersona(String nomPersona) {
        this.nomPersona = nomPersona;
    }

    public String retornarDatos() {
        return   nomPersona ;
    }

}
