package Modelo;

public class Entrenador extends Persona {

    private int idFederacion;
    
    

    public Entrenador() {
    }

   

    public Entrenador(int idFederacion, int id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.idFederacion = idFederacion;
    }

    public int getIdFederacion() {
        return idFederacion;
    }

    public void setIdFederacion(int idFederacion) {
        this.idFederacion = idFederacion;
    }

   

    
    @Override
    public String retornarDatos() {
        
          return "[Entrenador]"+ super.retornarDatos()+ "\n[idFederacion = " + idFederacion+"]" ;
            
       
        
    }

}
