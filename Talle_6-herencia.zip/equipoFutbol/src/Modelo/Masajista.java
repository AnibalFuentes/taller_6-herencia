package Modelo;

public class Masajista extends Persona {

    private String titulacion;
    private int aniosExp;

    public Masajista() {
    }

    public Masajista(String titulacion, int aniosExp, int id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.titulacion = titulacion;
        this.aniosExp = aniosExp;
    }

    public String getTitulacion() {
        return titulacion;
    }

    public void setTitulacion(String titulacion) {
        this.titulacion = titulacion;
    }

    public int getAniosExp() {
        return aniosExp;
    }

    public void setAniosExp(int aniosExp) {
        this.aniosExp = aniosExp;
    }

    

    @Override
    public String retornarDatos() {
        return "[Masajista]" + super.retornarDatos() + "\n[titulacion = " + titulacion +"]"+ "\n[añosExperiencia = " + aniosExp+"]" ;
    }

}
