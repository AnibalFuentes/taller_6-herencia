package vista;

import Modelo.*;

public class prueba {

    public static void main(String[] args) {
        // TODO code application logic here

        Persona persona1 = new Persona(1067593915, "jose", "gomez", 79);
        System.out.println("[Persona]" + persona1.retornarDatos());

        System.out.println("-------------------------------------|");

        Entrenador entrenador1 = new Entrenador(1525, 10445665, "juan", "guerra", 50);
        System.out.println(entrenador1.retornarDatos());

        System.out.println("-------------------------------------|");

        Futbolista futbolista1 = new Futbolista(23,"FUENTES",1067593915,"anibal","fuentes",17);
        System.out.println(futbolista1.retornarDatos());

        System.out.println("-------------------------------------|");

        Masajista masajista1 = new Masajista("fisioterapeuta", 5, 1067593915, "pedro", "sanchez", 35);
        System.out.println(masajista1.retornarDatos());
        
        System.out.println("-------------------------------------|");
    }

}
