package Vista;

import Modelo.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;

public class PruebaInstitucion {

    public static void main(String[] args) {

//        Empleado E1 = new Empleado("Rafa");
//        System.out.println(E1);
//        System.out.println("---------------------------------------------|");
//
//        Directivo D1 = new Directivo("Mario");
//        System.out.println(D1);
//        System.out.println("---------------------------------------------|");
//
//        Operario Op1 = new Operario("Alonso");
//        System.out.println(Op1);
//        System.out.println("---------------------------------------------|");
//
//        Oficial Of1 = new Oficial("Luis");
//        System.out.println(Of1);
//        System.out.println("---------------------------------------------|");
//
//        Tecnico T1 = new Tecnico("Pablo");
//        System.out.println(T1);
//        System.out.println("---------------------------------------------|");
//
//        System.out.println("La fecha actual es: " + LocalDate.now());
//        System.out.println("La hora actual es: " + LocalTime.now());
//        System.out.println("La fecha y hora actuales son: " + LocalDateTime.now());
//        System.out.println("El instante actual es: " + Instant.now());
//        System.out.println("La fecha y hora actuales con zona horaria son: " + ZonedDateTime.now());
            int i = 0;
        do { 
            System.out.println("i = " + i);
            i++;
            
                
               
            
            
        } while (i < 10);
    }

}
