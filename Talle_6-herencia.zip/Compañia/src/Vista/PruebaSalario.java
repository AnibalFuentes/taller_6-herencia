package Vista;

import Modelo.*;

public class PruebaSalario {

    public static void main(String[] args) {
        EmpleadoAsalariado Ea1 = new EmpleadoAsalariado(1600000);
        System.out.println("[Empleado Asalariado]\n[Sueldo: " + '$' + Ea1.SalarioAsalariado() + ']');
        System.out.println("------------------------------------|");
       
        EmpleadoHora Eh1 = new EmpleadoHora(15, 100000);
        System.out.println("[Empleado Por Horas]\n[Sueldo: " + '$' + Eh1.SalarioHoras() + ']');
        System.out.println("------------------------------------|");

        EmpleadoComision Ec1 = new EmpleadoComision(10000000, 20);
        System.out.println("[Empleado Comision]\nSueldo: " + '$' + Ec1.SalarioComision());
        System.out.println("------------------------------------|");

        EmpleadoAsalariadoComision Eac1 = new EmpleadoAsalariadoComision(1500000, 10000000, 10);
        System.out.println("[Empleado Asalariado por comisión]\n[Sueldo: " + '$' + Eac1.SalarioAsalariadoComision() + ']');
        System.out.println("[Salario + Bono de 10% : " + '$' + Eac1.Salario_Y_Bono() + ']');
        System.out.println("------------------------------------|");
        
        double nomina;
        nomina = Ea1.SalarioAsalariado()+Eh1.SalarioHoras()+Ec1.SalarioComision()+Eac1.Salario_Y_Bono();
        System.out.println("[Nomina Total: = " + "$" + nomina + "]");
        
        
    }
   


    

}
