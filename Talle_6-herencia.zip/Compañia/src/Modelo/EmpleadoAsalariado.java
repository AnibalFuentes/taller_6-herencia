
package Modelo;


public class EmpleadoAsalariado extends EmpleadoAsalariadoComision{

    public EmpleadoAsalariado() {
        
    }

    public EmpleadoAsalariado(double sueldoFijo) {
        super(sueldoFijo);
    }
    

    

   public double SalarioAsalariado(){
       return super.SalarioFijo();
   }
    
}
