
package Modelo;


public class EmpleadoAsalariadoComision {
    //ATRIBUTOS
    private double sueldoFijo;
    private double ventasSemana;
    private double pComision;
    //CONSTRUCTORES
    public EmpleadoAsalariadoComision() {
        
    }

    public EmpleadoAsalariadoComision(double sueldoFijo) {
        this.sueldoFijo = sueldoFijo;
    }

    public EmpleadoAsalariadoComision(double ventasSemana, double pComision) {
        this.ventasSemana = ventasSemana;
        this.pComision = pComision;
    }
    

    public EmpleadoAsalariadoComision(double sueldoFijo, double ventasSemana, double pComision) {
        this.sueldoFijo = sueldoFijo;
        this.ventasSemana = ventasSemana;
        this.pComision = pComision;
    }
    //GETTER Y SETTER
    public double getsueldoFijo() {
        return sueldoFijo;
    }

    public void setsueldoFijo(double sueldoFijo) {
        this.sueldoFijo = sueldoFijo;
    }

    public double getVentasSemana() {
        return ventasSemana;
    }

    public void setVentasSemana(double ventasSemana) {
        this.ventasSemana = ventasSemana;
    }

    public double getpComision() {
        return pComision;
       
    }

    public void setpComision(double pComision) {
        this.pComision = pComision;
    }
    //METODOS
    public double SalarioFijo(){
        return sueldoFijo;
    }
    
    public double SalarioComision(){
        return ventasSemana * pComision/100;
    }
    
    public double SalarioAsalariadoComision(){
        return SalarioFijo()+SalarioComision();
    }
    public double Salario_Y_Bono(){
        return SalarioAsalariadoComision() + SalarioAsalariadoComision()*0.1;
    }
   
    
}
