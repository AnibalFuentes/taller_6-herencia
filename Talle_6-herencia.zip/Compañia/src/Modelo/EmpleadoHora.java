
package Modelo;


public class EmpleadoHora {
    
    private double HorasT;
    private double vHora;

    public EmpleadoHora() {
    }
    
    

    public EmpleadoHora(double HorasT, double vHora) {
        this.HorasT = HorasT;
        this.vHora = vHora;
    }

    public double getHorasT() {
        return HorasT;
    }

    public void setHorasT(double HorasT) {
        this.HorasT = HorasT;
    }

    public double getvHora() {
        return vHora;
    }

    public void setvHora(double vHora) {
        this.vHora = vHora;
    }
    
    public double SalarioHoras(){
        return HorasT * vHora ;
    }
    
    
    
}
