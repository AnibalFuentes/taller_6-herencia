
package Modelo;


public class EmpleadoComision extends EmpleadoAsalariadoComision{

    public EmpleadoComision() {
    }

    public EmpleadoComision(double ventasSemana, double pComision) {
        super(ventasSemana, pComision);
    }
    
    @Override
    public double SalarioComision(){
        return super.SalarioComision();
    }
    
    
    

    
    
    
    
}
