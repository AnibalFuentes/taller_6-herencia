/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vista;


import modelo.Cuadrilatero;
import modelo.Rectangulo;
import modelo.Trapecio;
import modelo.Triangulo;

/**
 *
 * @author luisc
 */
public class prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       
        Cuadrilatero p1 = new Cuadrilatero();
        
        
        Cuadrilatero p2 = new Cuadrilatero();
        
        
        Cuadrilatero p3 = new Cuadrilatero();
        
        
        Cuadrilatero p4 = new Cuadrilatero();
        
       
        
       Cuadrilatero la = new Cuadrilatero();
       int longituda = (int) (p1.coordenadas(2, 8) + p2.coordenadas(9, 2));
       
       
       Cuadrilatero lb = new Cuadrilatero();
       int longitudb = (int) (p2.coordenadas(9, 2) + p3.coordenadas(10, 1));
       
       
       Cuadrilatero lc = new Cuadrilatero();
       int longitudc = (int) (p3.coordenadas(10, 1) + p4.coordenadas(5, 6));
       
       
       Cuadrilatero ld = new Cuadrilatero();
       int longitudd = (int) (p4.coordenadas(5, 6) + p1.coordenadas(2, 8));
    
       
       Cuadrilatero area = new Cuadrilatero();
       float a1 = (float) ((float) (0.5)*(longituda * longitudd)+ java.lang.Math.sin(23));
       float a2 = (float) ((float) (0.5)*(longitudb * longitudc)+ java.lang.Math.sin(50));
        
        System.out.println("------->CUADRILATERO<-------");
        System.out.println("el area del Cuadrilatero es: " +(a1+a2));
        System.out.println();
        
        System.out.println("------->TRAPECIO<-------");
        Trapecio areaT = new Trapecio();
        int at =(int) (longitudc *((longituda +longitudb)/2));
        System.out.println("el area es: "+ (at));
        System.out.println();
        
        System.out.println("------->TRIANGULO<-------");
        Triangulo areatg = new Triangulo();
        float atg =(float) ((float) ((float) 1/2)*(longituda * longitudb) +java.lang.Math.sin(50));
        System.out.println("el area del Triangulo es: " +(atg));
        System.out.println();
        
        System.out.println("------->RECTANGULO<-------");
        Rectangulo arear = new Rectangulo();
        int ar =(int) (longituda * longitudc);
        System.out.println("el area del rectangulo es: " +(ar));
}
  
        }
