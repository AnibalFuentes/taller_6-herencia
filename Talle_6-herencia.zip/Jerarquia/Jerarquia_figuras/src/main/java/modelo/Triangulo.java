/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author luisc
 */
public class Triangulo extends Trapecio{
    private String triangulo;
    
    public Triangulo() {
        
    }

    public Triangulo(String triangulo) {
        this.triangulo = triangulo;
    }

    public Triangulo(String triangulo, String ttrapecio) {
        super(ttrapecio);
        this.triangulo = triangulo;
    }

    public Triangulo(String triangulo, String ttrapecio, int x, int y) {
        super(ttrapecio, x, y);
        this.triangulo = triangulo;
    }

    @Override
    public String retornarDatos() {
        return super.retornarDatos()+"Triangulo{" + "triangulo=" + triangulo + '}';
    }

    
}  
        
   
    
         
