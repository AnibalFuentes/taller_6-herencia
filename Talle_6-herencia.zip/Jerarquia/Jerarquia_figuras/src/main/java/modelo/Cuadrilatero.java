/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author luisc
 */
public class Cuadrilatero {

    private  int x;
    private  int y;
    

    public Cuadrilatero() {
        this.x=0;
        this.y=0;
    }

    public Cuadrilatero(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

     public double coordenadas(int x, int y){
        int dx = x - this.x;
        int dy = y - this.y;
        
        double dx2 = Math.pow(dx, 2);
        double dy2 = Math.pow(dy, 2);
        
        double vertice = Math.sqrt(dx2 + dy2);
        return vertice;
    
    }

    public String retornarDatos() {
        return "Cuadrilatero{" + "x=" + x + ", y=" + y + '}';
    }

         
}  
     
