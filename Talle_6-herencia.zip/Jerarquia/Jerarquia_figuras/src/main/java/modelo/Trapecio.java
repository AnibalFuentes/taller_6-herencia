/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author luisc
 */
    public class Trapecio extends Cuadrilatero{
        String ttrapecio;

    public Trapecio() {
        
    }

    public Trapecio(String ttrapecio) {
        this.ttrapecio = ttrapecio;
    }

    public Trapecio(String ttrapecio, int x, int y) {
        super(x, y);
        this.ttrapecio = ttrapecio;
    }

    @Override
    public String retornarDatos() {
        return super.retornarDatos()+"Trapecio{" + "ttrapecio=" + ttrapecio + '}';
    }

    }   
 
    

