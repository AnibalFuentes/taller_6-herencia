/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author luisc
 */
public class Rectangulo extends Triangulo{
    private String rectangulo;

     public Rectangulo(){
         
         
     }
    public String getRectangulo() {
        return rectangulo;
    }

    public void setRectangulo(String rectangulo) {
        this.rectangulo = rectangulo;
    }

    public String getTtrapecio() {
        return ttrapecio;
    }

    public void setTtrapecio(String ttrapecio) {
        this.ttrapecio = ttrapecio;
    }

    public Rectangulo(String rectangulo) {
        this.rectangulo = rectangulo;
    }

    public Rectangulo(String rectangulo, String triangulo) {
        super(triangulo);
        this.rectangulo = rectangulo;
    }

    public Rectangulo(String rectangulo, String triangulo, String ttrapecio) {
        super(triangulo, ttrapecio);
        this.rectangulo = rectangulo;
    }

    public Rectangulo(String rectangulo, String triangulo, String ttrapecio, int x, int y) {
        super(triangulo, ttrapecio, x, y);
        this.rectangulo = rectangulo;
        
        
    }

    @Override
    public String toString() {
        return super.retornarDatos()+"Rectangulo{" + "rectangulo=" + rectangulo + '}';
    }
}

    
